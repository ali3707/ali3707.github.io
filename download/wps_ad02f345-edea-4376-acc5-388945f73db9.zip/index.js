var daka = require('./lib/wps')

exports.main_handler = async () => {
    sckey='SCU102935T1fa6eb66e1fd5e1ad173c4a1c2c71be15ef7438defdee'
    sid='V02STkZidqh3nOepzkFrwRVgAWdlRyY00a416bc1001296c089';
    wpsinviteid='311869577';
  daka(sid,wpsinviteid,sckey)
};
